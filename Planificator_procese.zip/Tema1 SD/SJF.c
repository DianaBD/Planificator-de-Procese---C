#include "biblioteci.h"
void tick2(Queue ready,Node running,Queue waiting);
void new(Queue ready,char *comanda);
void event(Queue ready,Queue waiting,char *comanda);

void SJF(FILE *f,char *out)
{	FILE *g=fopen(out,"w+");
	/*initializaz cozile running si waiting*/
	Queue ready=initQueue(),waiting=initQueue();
	/*initializaz nodul running cu procesul "nimic",care va sta in 
	coada ready pana cand se va adauga un proces real */
	Node running=initNode("nimic",100,0,0,0);
	char comanda[100];
	fgets(comanda,100,f);
	/*cat timp se citeste o comanda(un rand) din fisierul de input,
	apelez functia care efectueaza comanda respectiva in cazurile tick,
	add, multiple add si event, sau pur si simplu afisez nodul running 
	sau il adaug la coada waiting in cazurile show si wait*/	
	while(fgets(comanda,100,f))
	{	printf("%s",comanda);
		switch(comanda[0])
		{	
			case 'a': 
				new(ready,comanda+2);
				tick2(ready,running,waiting);
				break;
			case 'm':
				new(ready,comanda+3);
				tick2(ready,running,waiting);
				break;
			case 't':
				tick2(ready,running,waiting);
				break;
			case 'w':
				waiting=enqueue(waiting,running->nume,running->viata,running->nivel,-1,-1);
				running->viata=1;
				printf("waiting:");printQueue(waiting);
				tick2(ready,running,waiting);
				break;
			case 'e':
				event(ready,waiting,comanda+2);
				tick2(ready,running,waiting);
				break;
			case 's':
				/*daca in nodul running exista un proces
				cu timpul de viata mai mare ca 0 si diferit de "nimic" il scriu in
				fisierul deoutput*/
				if(strcmp(running->nume,"nimic")!=0&&(running->viata>0))
				{	
					fprintf(g,"%s ",running->nume);
					fprintf(g,"%d\n",running->viata);
				}
				/*daca nu exista un astfel de proces in nodul "running", scriu \n in fisier*/
				else fprintf(g,"\n");
				break;
	}
	fclose(g);
	freeNode(running);
	freeQueue(ready);
	freeQueue(waiting);
}

/*functie care efectueaza comanda tick pentru planificarea SJF*/
void tick2(Queue ready,Node running,Queue waiting)
{	
	/*scade timpul de viata al procesului din running*/
	running->viata--;
	/*daca timpul de viata a ajuns la 0 sau in nodul running nu este nici un proces,
	adica procesul "nimic" de la initializarea nodului, si in coada ready exista cel putin 
	un proces, se inlocuieste procesul din running*/ 
	if((running->viata<=0||strcmp(running->nume,"nimic")==0)&&ready->size>=1)
	{	Node p=ready->head, min=p,prev=p,aux,tmp;
		int i=1;
		printf("Size ready: %d\n", ready->size);
		/*caut nodul cu cel mai mic timp de viata*/
		for(i=1;i<ready->size;i++)
		{	tmp=p;printf("%d\n",i);
			p=p->next;
			if(p->viata<min->viata)
			{	prev=tmp;printf("prev: ");printNode(prev);
				min=p;printf("min: ");printNode(min);
			}
			
		}
		aux=initNode(min->nume,min->viata,min->nivel,0,0);
		strcpy(running->nume,aux->nume);
		running->viata=aux->viata;
		running->nivel=aux->nivel;
		if(min!=ready->head&&min->next!=NULL)
		{	printf("p: ");printNode(p);
			printf("min->next: ");printNode(min->next);
			prev->next=min->next;
			free(min);
		}	
		else if(min==ready->head) 
		{	printf("primul\n");
			ready->head=ready->head->next;
			free(min);
		}
		else if(min->next==NULL)
		 {	printf("ultimul\n");
			ready->tail=prev;
			ready->tail->next=NULL;
			free(min);
		}
		ready->size--;
		//aux=p=prev=tmp=NULL;free(aux);free(p);free(prev);free(tmp);
	}
	printf("running2:");printNode(running);
}





