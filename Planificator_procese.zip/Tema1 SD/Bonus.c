#include "biblioteci.h"
void tick5(Queue ready,Node running,Queue waiting,int cuanta,int *ceas);
void new(Queue ready,char *comanda);
void event(Queue ready,Queue waiting,char *comanda);
void Bonus(FILE *f,char *out,int cuanta)
{	FILE *g=fopen(out,"w+");
	Queue ready=initQueue(),waiting=initQueue();
	Node running=initNode("nimic",100,-1,0,0);
	char comanda[100];
	int ceas=0;
	fgets(comanda,100,f);
		
	while(fgets(comanda,100,f))
	{	printf("%s",comanda);
		switch(comanda[0])
		{	
			case 'a': 
				new(ready,comanda+2);
				tick5(ready,running,waiting,cuanta,&ceas);
				break;
			case 'm':
				new(ready,comanda+3);
				tick5(ready,running,waiting,cuanta,&ceas);
				break;
			case 't':
				tick5(ready,running,waiting,cuanta,&ceas);
				break;
			case 'w':
				(running->w)++;
				if((running->w)==2)
				{
					(running->w)=0;
					(running->nivel)++;
					printf("creste nivelul la: %d\n",running->nivel);
				}
				waiting=enqueue(waiting,running->nume,running->viata,running->nivel,running->r,running->w);
				
				running->viata=1;
				printf("waiting:");printQueue(waiting);
				tick5(ready,running,waiting,cuanta,&ceas);
				break;
			case 'e':
				event/*3*/(ready,waiting,comanda+2);
				tick5(ready,running,waiting,cuanta,&ceas);
				break;
			case 's':
				if(strcmp(running->nume,"nimic")!=0&&(running->viata>0))
				{	//fprintf(g,"lala");
					fprintf(g,"%s ",running->nume);
					fprintf(g,"%d\n",running->viata);
					//fprintf(g,"%d\n",running->nivel);
					printf("%s %d %d %d %d\n",running->nume,running->viata,running->nivel,running->r,running->w);
				}
				else {fprintf(g,"\n");printf("\n");}
				break;
		}
	printf("ready:");if(ready->size>=1) {printQueue(ready);printf("\n");}
			else printf("\n\n");
	}
	//printQueue(ready);printf("\n");
	fclose(g);
	freeNode(running);
	freeQueue(ready);
	freeQueue(waiting);
}

void tick5(Queue ready,Node running,Queue waiting,int cuanta,int *ceas)
{	running->viata--;printf("running1:");printNode(running);
	Node p=ready->head, max=p,prev=p,tmp;
	int i=1;
	if(ready->size>=1)
	{	
		
		printf("Size ready: %d\n", ready->size);
		for(i=1;i<ready->size;i++)
		{	tmp=p;printf("%d\n",i);
			p=p->next;
			if(p->nivel>max->nivel)
			{	
				//prev2=prev;printf("prev2: ");printNode(prev2);
				//max2=max;printf("max2: ");printNode(max2);
				prev=tmp;printf("prev: ");printNode(prev);
				max=p;printf("max: ");printNode(max);
			}
			
		}
	}
	else max=initNode("nimic",0,0,0,0);
	if((running->viata<=0||strcmp(running->nume,"nimic")==0||
*ceas==cuanta||(max->nivel>running->nivel&&strcmp(max->nume,"nimic")))&&ready->size>=1)
	{	
		if((*ceas==cuanta&&running->viata>0)||(max->nivel>running->nivel&&strcmp(running->nume,"nimic")))
		{	(running->r)++;
			if((running->r)==2)
			{
				(running->r)=0;
				(running->nivel)--;
				printf("!!! scade nivelul lui %s la: %d\n",running->nume,running->nivel);
			}
			ready=enqueue(ready,running->nume,running->viata,running->nivel,running->r,running->w);
			/*(ready->tail->r)++*/;printf("adaug la ready:");printNode(ready->tail);
			
		}
		*ceas=0;
		if(ready->size>=1)
		{	
			p=ready->head;max=p;prev=p;i=1;
			printf("Size ready: %d\n", ready->size);
			for(i=1;i<ready->size;i++)
			{	tmp=p;printf("%d\n",i);
				p=p->next;
				if(p->nivel>max->nivel)
				{	
					//prev2=prev;printf("prev2: ");printNode(prev2);
					//max2=max;printf("max2: ");printNode(max2);
					prev=tmp;printf("prev: ");printNode(prev);
					max=p;printf("max: ");printNode(max);
				}
				
			}
		}
		//
		Node aux;
		
		aux=initNode(max->nume,max->viata,max->nivel,max->r,max->w);
		printf("Nume max, aux, i: %s %s %d\n",max->nume,aux->nume,i);
		strcpy(running->nume,aux->nume);
		running->viata=aux->viata;
		running->nivel=aux->nivel;
		running->r=aux->r;
		running->w=aux->w;
		if(max!=ready->head&&max->next!=NULL)
		{	printf("p: ");printNode(p);
			//printf("min->next: ");printNode(min->next);
			prev->next=max->next;
			free(max);
		}	
		else if(max==ready->head) 
		{	printf("primul\n");
			ready->head=ready->head->next;
			free(max);
		}
		else if(max->next==NULL)
		 {	printf("ultimul\n");
			ready->tail=prev;
			ready->tail->next=NULL;
			free(max);
		}
		ready->size--;
		free(aux);
	
	}
	else if(running->viata<=0) *ceas=0;
	++(*ceas);printf("ceas: %d\n",*ceas);		
	printf("running2:");printNode(running);
}


