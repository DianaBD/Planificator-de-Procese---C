#include "biblioteci.h"
void tick4(Queue ready,Node running,Queue waiting,int cuanta,int *ceas);
void new(Queue ready,char *comanda);
void event(Queue ready,Queue waiting,char *comanda);
void PP(FILE *f,char *out,int cuanta)
{	FILE *g=fopen(out,"w+");
	Queue ready=initQueue(),waiting=initQueue();
	Node running=initNode("nimic",100,-1,0,0);
	char comanda[100];
	int ceas=0;
	fgets(comanda,100,f);
		
	while(fgets(comanda,100,f))
	{	
		switch(comanda[0])
		{	
			case 'a': 
				new(ready,comanda+2);
				tick4(ready,running,waiting,cuanta,&ceas);
				break;
			case 'm':
				new(ready,comanda+3);
				tick4(ready,running,waiting,cuanta,&ceas);
				break;
			case 't':
				tick4(ready,running,waiting,cuanta,&ceas);
				break;
			case 'w':
				waiting=enqueue(waiting,running->nume,running->viata,running->nivel,-1,-1);
				running->viata=1;
				printf("waiting:");printQueue(waiting);
				tick4(ready,running,waiting,cuanta,&ceas);
				break;
			case 'e':
				event/*3*/(ready,waiting,comanda+2);
				tick4(ready,running,waiting,cuanta,&ceas);
				break;
			case 's':
				if(strcmp(running->nume,"nimic")!=0&&(running->viata>0))
				{	
					fprintf(g,"%s ",running->nume);
					fprintf(g,"%d\n",running->viata);
				}
				else fprintf(g,"\n");
				break;
		}
	}

	fclose(g);
	freeNode(running);
	freeQueue(ready);
	freeQueue(waiting);
}

void tick4(Queue ready,Node running,Queue waiting,int cuanta,int *ceas)
{	running->viata--;printf("running1:");
	Node p=ready->head, max=p,prev=p,tmp;
	int i=1;
	if(ready->size>=1)
	{	
		printf("Size ready: %d\n", ready->size);
		for(i=1;i<ready->size;i++)
		{	tmp=p;
			p=p->next;
			if(p->nivel>max->nivel)
			{	prev=tmp;
				max=p;
			}
			
		}
	}
	else max=initNode("nimic",0,0,0,0);
	if((running->viata<=0||strcmp(running->nume,"nimic")==0||*ceas==cuanta||(max->nivel>running->nivel&&strcmp(max->nume,"nimic")))&&ready->size>=1)
	{	
		if((*ceas==cuanta&&running->viata>0)||(max->nivel>running->nivel&&strcmp(running->nume,"nimic")))
		{
			ready=enqueue(ready,running->nume,running->viata,running->nivel,0,0);
		}
		*ceas=0;
		if(ready->size>=1)
		{	
			p=ready->head;max=p;prev=p;i=1;
			printf("Size ready: %d\n", ready->size);
			for(i=1;i<ready->size;i++)
			{	tmp=p;
				p=p->next;
				if(p->nivel>max->nivel)
				{	prev=tmp;
					max=p;
				}
				
			}
		}
		//
		Node aux;
		aux=initNode(max->nume,max->viata,max->nivel,0,0);
		printf("Nume max, aux, i: %s %s %d\n",max->nume,aux->nume,i);
		strcpy(running->nume,aux->nume);
		running->viata=aux->viata;
		running->nivel=aux->nivel;
		if(max!=ready->head&&max->next!=NULL)
		{	
			prev->next=max->next;
			free(max);
		}	
		else if(max==ready->head) 
		{	printf("primul\n");
			ready->head=ready->head->next;
			free(max);
		}
		else if(max->next==NULL)
		 {	printf("ultimul\n");
			ready->tail=prev;
			ready->tail->next=NULL;
			free(max);
		}
		ready->size--;
		//aux=p=prev=tmp=NULL;free(aux);free(p);free(prev);free(tmp);
	
	}
	else if(running->viata<=0) *ceas=0;
	++(*ceas);printf("ceas: %d\n",*ceas);		
	printf("running2:");printNode(running);
}





