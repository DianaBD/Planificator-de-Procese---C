#include "biblioteci.h"
void tick(Queue ready,Node running,Queue waiting);
void new(Queue ready,char *comanda);
void event(Queue ready,Queue waiting,char *comanda);
void FCFS(FILE *f)
{	
	FILE *g=fopen("FCFS/out","w");
	Queue ready=initQueue(),waiting=initQueue();
	Node running=initNode("nimic",100,0,0,0);
	char comanda[100];
	fgets(comanda,100,f);	
	while(fgets(comanda,100,f))
	{	printf("%s",comanda);
		switch(comanda[0])
		{	
			case 'a': 
				new(ready,comanda+2);
				tick(ready,running,waiting);
				break;
			case 'm':
				new(ready,comanda+3);
				tick(ready,running,waiting);
				break;
			case 't':
				tick(ready,running,waiting);
				break;
			case 'w':
				waiting=enqueue(waiting,running->nume,running->viata,-1,-1,-1);
				running->viata=1;
				printf("waiting:");printQueue(waiting);
				tick(ready,running,waiting);
				break;
			case 'e':
				event(ready,waiting,comanda+2);
				tick(ready,running,waiting);
				break;
			case 's':
				if(strcmp(running->nume,"nimic")!=0)
					fprintf(g,"%s %d\n",running->nume,running->viata);
				else fprintf(g,"\n");
				break;

		}
	printf("ready:");if(ready->size>=1) {printQueue(ready);printf("\n");}
			else printf("\n\n");
	}
	fclose(g);
	fclose(f);
	//printQueue(ready);printf("\n");
}

void new(Queue ready,char *comanda)
{	
	char *nume;
	int viata;	
	nume=strtok(comanda, " ");
	viata=(atoi)(strtok(NULL, " "));
	ready=enqueue(ready,nume,viata,-1,-1,-1);
	nume=strtok(NULL, " ");
	while(nume!=NULL)
	{	
		viata=(atoi)(strtok(NULL, " "));
		ready=enqueue(ready,nume,viata,-1,-1,-1);
		nume=strtok(NULL, " ");
	}
}

void tick(Queue ready,Node running,Queue waiting)
{	running->viata--;printf("running1:");printNode(running);
	if(running->viata<=0||(ready->size>=1&&strcmp(running->nume,"nimic")==0))
	{	Node p=ready->head;
		strcpy(running->nume,p->nume);
		running->viata=p->viata;
		ready->head=ready->head->next;
		ready->size--;
		free(p);
	}
	printf("running2:");printNode(running);
}

void event(Queue ready,Queue waiting,char *comanda)
{	
	Node proces=initNode("nimic",1,0,0,0);;
	strcpy(proces->nume,comanda);
	(proces->nume)[strlen(proces->nume)-1]='\0';//printf("%s",proces->nume);	
	Node aux=waiting->head;//printf("%s",aux->nume);
	Node p=aux;
	while((strcmp(aux->nume,proces->nume))!=0)
	{	p=aux;
		aux=aux->next;
	}
	ready=enqueue(ready,aux->nume,aux->viata,-1,-1,-1);
	if(aux!=waiting->head)
	{
		p->next=aux->next;
		free(aux);
	}
	else waiting=dequeue(waiting);
	printf("waiting:");printQueue(waiting);
}



