#include "biblioteci.h"

void FCFS(FILE *f,FILE *g);
void SJF(FILE *f,FILE *g);
void RR(FILE *f,FILE *g);
void PP(FILE *f,FILE *g);
void Bonus(FILE *f,FILE *g);

int main(int argc,char *argv[])
{

	FILE *f=fopen(argv[1],"r");
	FILE *g=fopen(argv[2],"w");
	int planificare;
	fscanf(f,"%d",&planificare);printf("%d\n",planificare);
	/*if(planificare==3)
	{
		int x;
		fscanf(f,"%d",&x);printf("%d\n",x);
	}
	else if(planificare==4||planificare==5)
	{
		int x,y;
		fscanf(f,"%d%d",&x,&y);printf("%d%d\n",x,y);
	}*/

	switch(planificare)
	{
		case 1:
			FCFS(f,g);
			break;
		/*case 2:
			SJF(f);
			break;
		case 3:
			RR(f);
			break;
		case 4:
			PP(f);
			break;
		case 5:
			Bonus(f);
			break;*/
	}	
	fclose(f);
	fclose(g);	
	return 0;
}
