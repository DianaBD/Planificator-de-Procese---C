#include "biblioteci.h"

Node initNode(char *nume,int viata,int nivel,int r,int w) {
	Node new=malloc(sizeof(struct node));
	strcpy(new->nume,nume);
	new->viata=viata;
	new->nivel=nivel;
	new->r=r;
	new->w=w;
	new->next=NULL;
	return new;
}

Node freeNode(Node node) {
	Node n=node;
	free(n);
	return NULL;
}

Queue initQueue() {
        Queue queue=(Queue)malloc(sizeof(Queue));
        queue->head=malloc(sizeof(Node));
	queue->tail=malloc(sizeof(Node));
	//queue->head=NULL;
        queue->size=0;
	return queue;
}

Queue enqueue(Queue queue, char *nume,int viata,int nivel,int r,int w) {
	if(queue==NULL) printf("NULA\n");
        /*if (queue->head=NULL)
        {
            queue=initQueue(nume,viata,nivel,r,w);
		return queue;
        }*/
        Node new = initNode(nume,viata,nivel,r,w);
	if(queue->size==0) {
		queue->head=new;
		queue->tail=new;
		queue->size++;
		return queue;
	}
        queue->tail->next = new;
	queue->tail = queue->tail->next;
        queue->size++;
	//if(queue->size==2)
	//	queue->head->next=new;
	//if(queue==NULL) printf("NULA\n");	
        return queue;
}

int isEmptyQueue(Queue queue) {
	if (queue->size==0||queue->head==NULL)
            return 1;
        return 0;
}

Queue dequeue(Queue queue) {
        if (queue == NULL)
            return queue;
        if (queue->head == queue->tail)
        {
            free(queue->head);
		queue->size=0;
            return queue;
        }
        Node a;
        a = queue->head;
        queue->head = queue->head->next;
        free(a);
        queue->size--;
        return queue;
}

/*char* first(Queue queue) {
	if (queue)
            return queue->head->nume;
	return NULL;
}
*/
Queue freeQueue(Queue queue) {
	Node tmp,aux;tmp=queue->head;
	while(tmp->next!=NULL){
		aux=tmp;
		tmp=tmp->next;
		freeNode(aux);
	}
		
	free(queue);	
	return NULL;
}

void printNode(Node n){
	printf("%s %d %d %d %d\n",n->nume,n->viata,n->nivel,n->w,n->r);
}

void printQueue(Queue q){
	Node tmp=q->head;
	int i;
	for(i=1;i<=q->size;i++){
		printNode(tmp);
		tmp=tmp->next;
	}
}
