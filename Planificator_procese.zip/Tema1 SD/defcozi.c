#include "biblioteci.h"

/*functie de initializare nod*/
Node initNode(char *nume,int viata,int nivel,int r,int w) {
	Node new=malloc(sizeof(struct node));
	strcpy(new->nume,nume);
	new->viata=viata;
	new->nivel=nivel;
	new->r=r;
	new->w=w;
	new->next=NULL;
	return new;
}

/*functie de eliberare memorie nid*/
Node freeNode(Node node) {
	free(node);
	return NULL;
}

/*functie de initializare coada*/
Queue initQueue() {
        Queue queue=malloc(sizeof(Queue));
        queue->size=0;
	return queue;
}

/*functie de adaugare in coada*/
Queue enqueue(Queue queue, char *nume,int viata,int nivel,int r,int w) {

        Node new = initNode(nume,viata,nivel,r,w);
	if(queue->size==0) {
		queue->head=new;
		queue->tail=new;
		queue->size++;
		return queue;
	}
        queue->tail->next = new;
	queue->tail = queue->tail->next;
        queue->size++;	
        return queue;
}

/*functie care verifica daca coada e goala*/
int isEmptyQueue(Queue queue) {
	if (queue->size==0||queue->head==NULL)
            return 1;
        return 0;
}

/*scoate din coada primul element*/
Queue dequeue(Queue queue) {
        if (queue == NULL)
            return queue;
        Node a;
        a = queue->head;
        queue->head = queue->head->next;
        freeNode(a);
        queue->size--;
        return queue;
}

/*elibereaza memoria alocata cozii*/
Queue freeQueue(Queue queue) {

	Node tmp;
	while(queue->head!=NULL){
	
		tmp=queue->head;
		queue->head=queue->head->next;
		free(tmp);
	}
	free(queue);
	return NULL;
}

/*printare nod si coada - foarte utile la debugging*/
void printNode(Node n){
	printf("%s %d %d %d %d\n",n->nume,n->viata,n->nivel,n->r,n->w);
}

void printQueue(Queue q){
	Node tmp=q->head;
	int i;
	for(i=1;i<=q->size-1;i++){
		printNode(tmp);
		tmp=tmp->next;
	}

}
