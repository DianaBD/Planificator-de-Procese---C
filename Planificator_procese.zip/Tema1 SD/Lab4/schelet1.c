/*
*	Created by Nan Mihai on 16.03.2017
*	Copyright (c) 2017 Nan Mihai. All rights reserved.
*	Laborator 4 - Structuri de date
*	Grupa 312CC
*	Facultatea de Automatica si Calculatoare
*	Anul Universitar 2016-2017, Seria CC
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define SIZE	100

#define sd_assert(message, test) \
	do { \
		if (!(test)) \
			return message; \
	} while (0)

#define sd_run_test(test, score) \
	do { \
		char *message = test(); \
		tests_run++; \
		if (message) \
			return message; \
		else \
			total_score += score; \
	} while (0)


int tests_run = 0;
float total_score = 0;

typedef struct node {
	int value;
	struct node* next;
}*Node;

//Definitia structurii de date pentru stiva
typedef struct stack {
	Node top;
	int size;
}*Stack;

//Definitia structurii de date pentru coada
typedef struct queue {
	Node head, tail;
	int size;
}*Queue;

typedef struct list {
	int value;
	struct list* next;
	int first;
}*CircularList;

Node initNode(int value) {
	Node new=malloc(sizeof(struct node));
	new->value=value;
	new->next=NULL;
	return new;
}

Node freeNode(Node node) {
	Node n=node;
	free(n);
	return NULL;
}


/**
 * Problema 1 - Stiva
 */
Stack initStack(int value) {
	Stack new;
	new=malloc(sizeof(struct stack));
	new->top=initNode(value);
	new->size=1;
	return new;
}

int isEmptyStack(Stack stack) {
	if(stack==NULL||stack->size==0)
		return 1;
	else return 0;
}	

Stack push(Stack stack, int value) {
	Node n;
	if(isEmptyStack(stack)) {
		stack=initStack(value);
		//stack->top=initNode(value);
		return stack;
		}
	n=initNode(value);
	n->next=stack->top;
	stack->top=n;
	stack->size++;
	return stack;
}

Stack pop(Stack stack) {
	Node tmp;
	if(!isEmptyStack(stack)){
		tmp=stack->top;
		stack->top=stack->top->next;
		freeNode(tmp);
		stack->size--;
		return stack;
	}
	return NULL;
}

int top(Stack stack) {
	int n;
	if(!isEmptyStack(stack)){
		n=stack->top->value;
		return n;
	} 

	else return -1;	
}

Stack freeStack(Stack stack) {
	Node tmp,aux;tmp=stack->top;
	while(tmp!=NULL){
		aux=tmp;
		tmp=tmp->next;
		free(aux);
	}
	free(stack);
	return NULL;
}

/**
 * Problema 2 - Coada
 */
int isEmptyQueue(Queue queue);
Queue initQueue(int value) {
	Queue queue=malloc(sizeof(struct queue));
	//Node head,tail;
	//head=initNode(value);
	//tail=initNode(value);
	queue->head=queue->tail=initNode(value);
	queue->size=1;
	return queue;

}

Queue enqueue(Queue queue, int value) {
	if(queue==NULL || queue->head==NULL){
		queue=initQueue(value);
		return queue;
	}
	
		Node new=initNode(value);
		queue->tail->next=new;
		queue->tail=new;
		//if(queue->size==1)
			//queue->head->next=queue->tail;
		queue->size++;
		/*}
		
		else {
			Node new=initNode(value);
			queue->head=new;
			queue->size++;
			}*/
			
		return queue;
	
	
	
}

int isEmptyQueue(Queue queue) {
	
	if(queue==NULL)
		return 1;
	return 0;
}

Queue dequeue(Queue queue) {
	if(queue==NULL)
		return queue;
	if (queue->head == queue->tail)
        {
            free(queue->head);
            return queue;
        }
		Node n=queue->head;
		queue->head = queue->head->next;
		freeNode(n);
		queue->size--;
		return queue;
}

int first(Queue queue) {
	if(queue)
		return queue->head->value;
	return -1;
}

Queue freeQueue(Queue queue) {return NULL;
	/*Node tmp=queue->head,aux;
	while(tmp!=NULL){
		aux=tmp;
		tmp=tmp->next;
		free(aux);
	}
	free(queue);	
	return NULL;*/
}

/**
 * Problema 3 - Ce stuctura de date puteti utiliza?
 */
int checkExpression(const char* exp) {
	int i=0;
	Stack stack;
	while(i<strlen(exp)){
		if(exp[i]=='('||exp[i]=='[')
			stack=push(stack,(int)exp[i++]);
		else if((exp[i]==']'&&stack->top->value==(int)'[')||( exp[i]==')'&&stack->top->value==(int)')')){
				stack=pop(stack);
				i++;
			}
			
	}	
	if(stack->size==0) return 1;
		
	return 0;
}

/*Queue vecini(char **m,int i,int j){
	Queue vecini;
	if(m[i-1][j-1]==' ') {vecini=enqueue(vecini,i-1);vecini=enqueue(vecini,j-1);}
	if(m[i-1][j]==' ') {vecini=enqueue(vecini,i-1);vecini=enqueue(vecini,j);}
	if(m[i-1][j+1]==' ') {vecini=enqueue(vecini,i-1);vecini=enqueue(vecini,j+1);}
	if(m[i][j-1]==' ') {vecini=enqueue(vecini,i);vecini=enqueue(vecini,j-1);}
	if(m[i-1][j+1]==' ') {vecini=enqueue(vecini,i-1);vecini=enqueue(vecini,j+1);}
	if(m[i+1][j-1]==' ') {vecini=enqueue(vecini,i+1);vecini=enqueue(vecini,j-1);}
	if(m[i+1][j]==' ') {vecini=enqueue(vecini,i+1);vecini=enqueue(vecini,j);}
	if(m[i+1][j+1]==' ') {vecini=enqueue(vecini,i+1);vecini=enqueue(vecini,j+1);}
	return vecini;
}
	

void drumuri(queue q1, queue q2, int lungime, char **matrice,int m, int n,int iR,int iJ,int jR,int jJ){
	int i,j;
	if(lungime==1){
		q1=vecini(matrice,iR,jR);
		q2=vecini(matrice,iJ,jJ);
	//compar q1 si q2
	//daca am gasit casuta comuna - end
	else drumuri(q1,q2,++lungime,matrice,m,n,iR,iJ,jR,j
	}
		
		
		
void romeoJulieta(char **mat,int n,int m){
	queue q1,q2;
	int i,j,iR,iJ,jR,jJ;
	for(i=0;i<n;i++)
		for(j=0;i<m;j++){
			if(mat[i][j]=='R') {iR=i;jR=j;}
			if(mat[i][j]=='J') {iJ=i;jJ=j;}
		}
	
/**
 * Bonus - Lista circulara simplu inlantuita
 */
int josephus(int number, const char *verse) {
	return 0;
	
}

int checkStack(Stack stack, int *vect, int len) {
	int i;
	if (stack == NULL) {
		return 0;
	}
	if (stack->size != len) {
		return 0;
	} else {
		for (i = len - 1; i >= 0; i--) {
			if (vect[i] != top(stack)) {
				printf("%d - %d\n", vect[i], top(stack));
				return 0;
			}
			stack = pop(stack);
		}
		return 1;
	}
}

int checkQueue(Queue queue, int *vect, int len) {
	int i;
	if (queue == NULL) {
		return 0;
	}
	if (queue->size != len) {
		return 0;
	} else {
		for (i = 0; i < len; i++) {
			if (vect[i] != first(queue)) {
				return 0;
			}
			queue = dequeue(queue);
		}
		return 1;
	}
}

void drawStack(Stack stack, char *name) {
	int i, size;
	FILE *stream;
	char *buffer;

	if (stack == NULL || name == NULL)
		return;
	stream = fopen("stack.dot", "w");
	fprintf(stream, "digraph stack {\n");
	fprintf(stream, "rankdir=LR;\nnode [shape=record, style=filled, fillcolor=yellow];\n");
	i = 0;
	fprintf(stream, "\"node0\" [\n label = \"");
	size = stack->size;
	while (!isEmptyStack(stack)) {
		fprintf(stream, "|<f%d> %d", i++, top(stack));
		stack = pop(stack);
	}
	fprintf(stream, "\", shape = \"record\", fillcolor = \"yellow\"];\n}");
	fclose(stream);
	buffer = (char*) malloc(SIZE*sizeof(char));
	sprintf(buffer, "dot stack.dot | neato -n -Tpng -o %s.png", name);
	system(buffer);
	free(buffer);
	stack->size = size;
}

static char *test_problema1() {
	int i, val, *vect, count = 0;
	vect = (int*) malloc(10*sizeof(int));
	Stack stack = NULL;
	for (i = 0; i < 10; i++) {
		val = rand() % 100;
		stack = push(stack, val);
		vect[i] = val;
	}

	sd_assert ("Problema 1 - Test1 picat!", checkStack(stack, vect, 10));
	free(vect);
	stack = freeStack(stack);
	stack = NULL;
	vect = (int*) malloc(100*sizeof(int));
	for (i = 0; i < 100; i++) {
		val = rand() % 100;
		stack = push(stack, val);
		if(i % 2 != 0) {
			stack = pop(stack);
		} else {
			vect[i/2] = val;
		}
	}

	sd_assert ("Problema 1 - Test2 picat!", checkStack(stack, vect, 50));
	free(vect);
	stack = freeStack(stack);
	stack = NULL;
	vect = (int*) malloc(1000*sizeof(int));
	for(i = 0; i < 1000; i++) {
		val = rand() % 5000;
		stack = push(stack, val);
		vect[count++] = val;
		if(val % 3 == 0) {
			stack = pop(stack);
			if(count > 0) {
				count--;
			}
			stack = pop(stack);
			if(count > 0) {
				count--;
			}
		}
	}
	sd_assert ("Problema 1 - Test3 picat!", checkStack(stack, vect, count));
	free(vect);
	stack = freeStack(stack);
	return 0;
}

static char *test_problema2() {
	int i, val, *vect, count = 0;
	vect = (int*) malloc(10*sizeof(int));
	Queue queue = NULL;
	for(i = 0; i < 10; i++) {
		val = rand() % 100;
		queue = enqueue(queue, val);
		vect[i] = val;
	}
	sd_assert ("Problema 2 - Test1 picat!", checkQueue(queue, vect, 10));
	free(vect);
	queue = freeQueue(queue);
	queue = NULL;
	vect = (int*) malloc(100*sizeof(int));
	for(i = 0; i < 100; i++) {
		val = rand() % 100;
		queue = enqueue(queue, val);
		if(i > 10 && i < 20) {
			queue = dequeue(queue);
		} 
		if(i >= 9) {
			vect[count++] = val;
		}
	}
	sd_assert ("Problema 2 - Test2 picat!", checkQueue(queue, vect, count));
	free(vect);
	queue = freeQueue(queue);
	queue = NULL;
	vect = (int*) malloc(1000*sizeof(int));
	count = 0;
	for(i = 0; i < 1000; i++) {
		val = rand() % 5000;
		queue = enqueue(queue, val);
		if(i > 100 && i < 300) {
			queue = dequeue(queue);
		} 
		if(i >= 199) {
			vect[count++] = val;
		}
	}
	sd_assert ("Problema 2 - Test3 picat!", checkQueue(queue, vect, count));
	free(vect);
	queue = freeQueue(queue);
	return 0;
}

static char *test_bonus() {
	sd_assert ("Problema 3 - Test1 picat!", josephus(10, "ala bala portocala bala ala\0") == 3);
	sd_assert ("Problema 3 - Test2 picat!", josephus(25, "Ciresica are mere, Ciresel vine si cere!\n\0") == 15);
	sd_assert ("Problema 3 - Test3 picat!", josephus(100, "Ala bala portocala\nToata casa-i alandala\0") == 68);
	sd_assert ("Problema 3 - Test4 picat!", josephus(7, "una mia suta lei ia te rog pe cine vrei din gramada cu purcei") == 1);
	sd_assert ("Problema 3 - Test5 picat!", josephus(250, "Intr-un castel de ciocolata  Traia o zana fermecata Ce culoare avea rochea de pe ea?\0") == 162);
	return 0;
}

static char *test_problema3() {
	sd_assert ("Bonus - Test1 picat!", checkExpression("[(([])([])()())]\0") == 1);
	sd_assert ("Bonus - Test2 picat!", checkExpression("(((([([([])])]))))\0") == 1);
	sd_assert ("Bonus - Test3 picat!", checkExpression("(([])((([()]))()))\0") == 1);
	sd_assert ("Bonus - Test4 picat!", checkExpression("((((((()))[]))))))(((((([]))))))))((((()[])))))))[]]]]]]]][[[[](((((((((((())\0") == 0);
	sd_assert ("Bonus - Test5 picat!", checkExpression("[](()(((([]((((())[]))))))))((((((((()((((()))))))((((((((())()))\0") == 0);
	sd_assert ("Bonus - Test6 picat!", checkExpression(")))))])))([[()(()())]]((((((((\0") == 0);
	return 0;
}

static char *all_tests() {
	sd_run_test(test_problema1, 3);
	sd_run_test(test_problema2, 3);
	sd_run_test(test_problema3, 2);
	sd_run_test(test_bonus, 4);
	return 0;
 }

int main() {
	srand(time(NULL));
	char *result = all_tests();
	if (result != 0) {
		printf("%s\n", result);
	}
	else {
		printf("Toate testele au trecut! Felicitari!\n");
	}
	printf("Punctajul obtinut este: %.2lf\n", total_score);
	printf("Teste rulate: %d\n", tests_run);
	return result != 0;
}
