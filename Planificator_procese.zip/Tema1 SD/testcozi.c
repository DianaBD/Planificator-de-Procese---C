#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

typedef struct node {
	int value;
	struct node* next;
}*Node;

//Definitia structurii de date pentru stiva
typedef struct stack {
	Node top;
	int size;
}*Stack;

//Definitia structurii de date pentru coada
typedef struct queue {
	Node head, tail;
	int size;
}*Queue;

Node initNode(int value) {
	Node new=malloc(sizeof(struct node));
	new->value=value;
	new->next=NULL;
	return new;
}

Node freeNode(Node node) {
	Node n=node;
	free(n);
	return NULL;
}

int isEmptyQueue(Queue queue);
Queue initQueue(int value) {
	Queue queue=malloc(sizeof(struct queue));
	//Node head,tail;
	//head=initNode(value);
	//tail=initNode(value);
	queue->head=initNode(value);
	queue->tail=queue->head;
	
	queue->size=1;
	return queue;

}

Queue enqueue(Queue queue, int value) {
	if(queue==NULL){
		initQueue(value);
		return queue;
	}
	else if(queue->size!=0){
		Node new=initNode(value);
		queue->tail->next=new;
		queue->tail=new;
		if(queue->size==1)
			queue->head->next=queue->tail;
		queue->size++;
		}
		
		else {
			Node new=initNode(value);
			queue->head=new;
			queue->size++;
			}
			
		return queue;
	
	
}

int isEmptyQueue(Queue queue) {
	
	if(queue==NULL||queue->size==0)
		return 1;
	return 0;
}

Queue dequeue(Queue queue) {
	if(!isEmptyQueue(queue)){
		Node n=queue->head;
		queue->head = queue->head->next;
		freeNode(n);
		queue->size--;
		return queue;
	}
	return NULL;
}

int first(Queue queue) {
	if(!isEmptyQueue(queue))
		return queue->head->value;
	return -1;
}

Queue freeQueue(Queue queue) {
	Node tmp=queue->head,aux;
	while(tmp!=NULL){
		aux=tmp;
		tmp=tmp->next;
		free(aux);
	}
	free(queue);	
	return NULL;
}

int main()
{
	Queue q0,q=initQueue(1);
	dequeue(q);
	printf("%d\n",isEmptyQueue(q));
	q=enqueue(q,2);
	q=enqueue(q,3);
	Node n=q->head;
	printf("%d\n",q->head->value);
	printf("%d\n",q->tail->value);
	dequeue(q);
	n=q->head;
	while(n!=NULL)
	{	printf("%d ",n->value);
		n=n->next;
	}
	printf("\n");
	return 0;
}
	
