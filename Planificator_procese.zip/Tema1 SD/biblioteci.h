#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

typedef struct node {
	char nume[21];	
	int viata;
	int nivel;
	int r;
	int w;
	struct node* next;
}*Node;

typedef struct queue {
	Node head;
	Node tail;
	int size;
}*Queue;

Node initNode(char *nume,int viata,int nivel,int r,int w);
Node freeNode(Node node);
Queue initQueue();
Queue enqueue(Queue queue,char *nume, int viata,int nivel,int r,int w);
int isEmptyQueue(Queue queue);
Queue dequeue(Queue queue);
Queue freeQueue(Queue queue);
void printNode(Node n);
void printQueue(Queue q);



