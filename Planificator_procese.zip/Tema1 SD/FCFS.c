#include "biblioteci.h"
void tick(Queue ready,Node running,Queue waiting);
void new(Queue ready,char *comanda);
void event(Queue ready,Queue waiting,char *comanda);
void FCFS(FILE *f,char *out)
{	
	FILE *g=fopen(out,"w+");
	/*initializaz cozile running si waiting*/
	Queue ready=initQueue(),waiting=initQueue();
	/*initializaz nodul running cu procesul "nimic",care va sta in 
	coada ready pana cand se va adauga un proces real */
	Node running=initNode("nimic",100,0,0,0);
	char comanda[100];
	fgets(comanda,100,f);
	/*cat timp se citeste o comanda(un rand) din fisierul de input,
	apelez functia care efectueaza comanda respectiva in cazurile tick,
	add, multiple add si event, sau pur si simplu afisez nodul running 
	sau il adaug la coada waiting in cazurile show si wait*/	
	while(fgets(comanda,100,f))
	{	
		switch(comanda[0])
		{	
			case 'a': 
				new(ready,comanda+2);
				tick(ready,running,waiting);
				break;
			case 'm':
				new(ready,comanda+3);
				tick(ready,running,waiting);
				break;
			case 't':
				tick(ready,running,waiting);
				break;
			case 'w':
				waiting=enqueue(waiting,running->nume,running->viata,running->nivel,-1,-1);
				running->viata=1;
				printf("waiting:");printQueue(waiting);
				tick(ready,running,waiting);
				break;
			case 'e':
				event(ready,waiting,comanda+2);
				tick(ready,running,waiting);
				break;
			case 's':
				/*daca in nodul running exista un proces
				cu timpul de viata mai mare ca 0 si diferit de "nimic" il scriu in
				fisierul deoutput*/
				if(strcmp(running->nume,"nimic")!=0&&(running->viata>0))
				{	
					fprintf(g,"%s ",running->nume);
					fprintf(g,"%d\n",running->viata);
				}
				/*daca nu exista un astfel de proces in nodul "running", scriu \n in fisier*/
				else fprintf(g,"\n");
				break;
		}
	}
	fclose(g);
	freeNode(running);
	freeQueue(ready);
	freeQueue(waiting);
}

/*functie care adauga unul(in cazul add) sau mai multe procese(multiple add) in coada ready*/
void new(Queue ready,char *comanda)
{	
	char *nume;
	int viata,nivel;	
	nume=strtok(comanda, " ");
	viata=(atoi)(strtok(NULL, " "));
	nivel=(atoi)(strtok(NULL, " "));
	ready=enqueue(ready,nume,viata,nivel,0,0);
	nume=strtok(NULL, " ");
	while(nume!=NULL)
	{	
		viata=(atoi)(strtok(NULL, " "));
		nivel=(atoi)(strtok(NULL, " "));
		ready=enqueue(ready,nume,viata,nivel,0,0);
		
		nume=strtok(NULL, " ");
		
	}
}

/*functie care efectueaza comanda tick*/
void tick(Queue ready,Node running,Queue waiting)
{	
	/*scade timpul de viata al procesului din running*/
	running->viata--;
	/*daca timpul de viata a ajuns la 0 sau in nodul running nu este nici un proces,
	adica procesul "nimic" de la initializarea nodului, si in coada ready exista cel putin 
	un proces, se inlocuieste procesul din running*/ 
	if((running->viata<=0||strcmp(running->nume,"nimic")==0)&&ready->size>=1)
	{	Node p=ready->head;
		strcpy(running->nume,p->nume);
		running->viata=p->viata;
		running->nivel=p->nivel;
		ready->head=ready->head->next;
		ready->size--;
		free(p);
	}
}

/*functie care efectueaza comanda event*/
void event(Queue ready,Queue waiting,char *comanda)
{	
	/*retin numele procesului ce trebuie scos din coada waiting in nodul "proces"*/
	Node proces=initNode("nimic",1,0,0,0);
	strcpy(proces->nume,comanda);
	/*scot \n de la sfarsitul stringului*/
	(proces->nume)[strlen(proces->nume)-1]='\0';
	/*caut procesulin coada waiting*/	
	Node aux=waiting->head;
	Node p=aux;
	while((strcmp(aux->nume,proces->nume))!=0)
	{	p=aux;
		aux=aux->next;
	}
	/*adaug procesul in coada ready*/
	ready=enqueue(ready,aux->nume,aux->viata,aux->nivel,aux->r,aux->w);
	/*sterg procesul din coada waiting*/
	if(aux!=waiting->head)
	{
		p->next=aux->next;
		free(aux);
	}
	else waiting=dequeue(waiting);
}



