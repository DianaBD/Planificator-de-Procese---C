#include "biblioteci.h"
void tick3(Queue ready,Node running,Queue waiting,int cuanta,int *ceas);
void new(Queue ready,char *comanda);
void event3(Queue ready,Queue waiting,char *comanda);
void RR(FILE *f,char *out,int cuanta)
{	FILE *g=fopen(out,"w+");
	Queue ready=initQueue(),waiting=initQueue();
	Node running=initNode("nimic",1000,0,0,0);
	char comanda[100];
	int ceas=0;
	fgets(comanda,100,f);

	while(fgets(comanda,100,f))
	{	
		switch(comanda[0])
		{	
			case 'a': 
				new(ready,comanda+2);
				tick3(ready,running,waiting,cuanta,&ceas);
				break;
			case 'm':
				new(ready,comanda+3);
				tick3(ready,running,waiting,cuanta,&ceas);
				break;
			case 't':
				tick3(ready,running,waiting,cuanta,&ceas);
				break;
			case 'w':
				waiting=enqueue(waiting,running->nume,running->viata,running->nivel,-1,-1);
				running->viata=1;
				printf("waiting:");printQueue(waiting);
				tick3(ready,running,waiting,cuanta,&ceas);
				break;
			case 'e':
				event3(ready,waiting,comanda+2);
				tick3(ready,running,waiting,cuanta,&ceas);
				break;
			case 's':
				if(strcmp(running->nume,"nimic")!=0&&(running->viata>0))
				{	
					fprintf(g,"%s ",running->nume);
					fprintf(g,"%d\n",running->viata);
				}
				else fprintf(g,"\n");
				break;

		}
	}
	freeNode(running);
	freeQueue(ready);
	freeQueue(waiting);
	fclose(g);
}


void tick3(Queue ready,Node running,Queue waiting,int cuanta,int *ceas)
{	running->viata--;
	
	
	if((running->viata<=0||strcmp(running->nume,"nimic")==0||*ceas==cuanta)&&ready->size>=1)
	{	if(*ceas==cuanta&&running->viata>0) 
		{
			ready=enqueue(ready,running->nume,running->viata,running->nivel,0,0);
		}
		*ceas=0;
		Node p=ready->head;
		strcpy(running->nume,p->nume);
		running->viata=p->viata;
		running->nivel=p->nivel;
		ready->head=ready->head->next;
		ready->size--;
		free(p);
	}
	else if(running->viata<=0) *ceas=0;
	++(*ceas);
}

void event3(Queue ready,Queue waiting,char *comanda)
{	
	Node proces=initNode("nimic",1,0,0,0);;
	strcpy(proces->nume,comanda);
	(proces->nume)[strlen(proces->nume)-1]='\0';
	Node aux=waiting->head;printf("%s",aux->nume);
	Node p=aux;
	while((strcmp(aux->nume,proces->nume))!=0)
	{	p=aux;
		aux=aux->next;
	}
	ready=enqueue(ready,aux->nume,aux->viata,aux->nivel,-1,-1);
	if(aux!=waiting->head)
	{
		p->next=aux->next;
		free(aux);
	}
	else waiting=dequeue(waiting);
	
}

