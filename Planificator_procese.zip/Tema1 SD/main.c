#include "biblioteci.h"

/*antetele functiilor pentru fiecare planificare*/
void FCFS(FILE *f,char *out);
void SJF(FILE *f,char *out);
void RR(FILE *f,char *out,int cuanta);
void PP(FILE *f,char *out,int cuanta);
void Bonus(FILE *f,char *out,int cuanta);

int main(int argc,char *argv[])
{
	/*deschid fisierul de citire*/
	FILE *f=fopen(argv[1],"r");
	int planificare,cuanta,nrnivele;
	/*citesc de pe primul rand planificarea care trebuie folosita (1 sau 2 sau 3 sau 4) */
	fscanf(f,"%d",&planificare);
	/*in functie de tipul planificarii, apelez functia corespunzatoare*/
	switch(planificare)
	{
		case 1:
			FCFS(f,argv[2]);
			break;
		case 2:
			SJF(f,argv[2]);
			break;
		case 3:
			fscanf(f,"%d",&cuanta);
			RR(f,argv[2],cuanta);
			break;
		case 4:
			fscanf(f,"%d",&cuanta);
			fscanf(f,"%d",&nrnivele);
			printf("%d\n",cuanta);
			printf("%d\n",nrnivele);
			PP(f,argv[2],cuanta);
			break;
		case 5:
			fscanf(f,"%d",&cuanta);
			fscanf(f,"%d",&nrnivele);
			printf("%d\n",cuanta);
			printf("%d\n",nrnivele);
			Bonus(f,argv[2],cuanta);
			break;
	}	
	
	fclose(f);
		
	return 0;
}
